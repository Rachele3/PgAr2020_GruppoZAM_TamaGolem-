package it.unibs.ing.progettoarnaldo.tamagolem;

import java.util.HashMap;
import java.util.Map;
/*
 * classe per la gestione dei singoli elementi
 */

public class Elementi {


	private String nome = "Primo nodo";
	private Map<Elementi, Integer> collegamentiElementi = new HashMap<Elementi, Integer>();
	
	
	// COSTRUTTORI DELLA CLASSE ELEMENTI
	public Elementi(String _nome, Map<Elementi, Integer> _nodiCollegati) 
	{
		nome = _nome;
		collegamentiElementi = _nodiCollegati;
	}
	
	public Elementi() {
		
	}

	
	/**
	 * METODO creaNodo.
	 * Si occupa di creare il nodo e i collegamenti tra gli elementi.
	 * 
	 * @param valoreTemp
	 * @param tempNodo
	 * @return un oggetto di tipo Elementi
	 */
	public Elementi creaNodo(Integer valoreTemp, Elementi tempNodo) 
	{
		this.nome = "Secondo nodo";
		this.collegamentiElementi.put(tempNodo, valoreTemp);
		
		return this;
	}
	
	
	/**
	 * METODO addCollegamento.
	 * Si occupa di aggiungere un collegamento dati i due parametri che rappresentano la chiave e il valore
	 * @param collegato
	 * @param ramo
	 */
	public void addCollegamento(Elementi collegato, Integer ramo){
		this.collegamentiElementi.put(collegato, ramo);
	}
	
	
	// METODI GETTERS per renderli visibili fuori dalla classe in cui sono dichiarati
	public String getNome() {
		return nome;
	}
	
	public Map<Elementi, Integer> getCollegamentiElementi() {
		return collegamentiElementi;
	}


}