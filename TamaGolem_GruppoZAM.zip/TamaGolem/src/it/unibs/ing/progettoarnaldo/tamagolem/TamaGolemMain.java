package it.unibs.ing.progettoarnaldo.tamagolem;


public class TamaGolemMain {

	private static final String SALUTO_INIZIALE = "BENVENUTO NELLA BATTAGLIA TAMAGOLEM\n";
	private static final String SALUTO_FINALE = "\nGRAZIE PER AVER GIOCATO. ALLA PROSSIMA";
	
	public static void main (String[] args) 
	{
		System.out.println(SALUTO_INIZIALE);
	
		TamaGolemMenu.match();
		
		System.out.println(SALUTO_FINALE);
	
	}
	
}
