package it.unibs.ing.progettoarnaldo.tamagolem;

import it.unibs.fp.mylib.InputDati;
/*
 * Classe per gestire lo scontro tra i tamagolem
 */

public class Scontro {
	
	private static final String INFO_GIOCATORE = "\t %s con %d Tamagolem\n";
	private static final String GIOC_PIETRE = "\n\n\nGiocatore %s scegli le tue pietre e fai allontanare %s\n";
	private static final String TAMA_PIETRE = "%s � pronto per scendere in campo. %s decidi le pietre con cui farlo combattere\n";
	private static final String MSG_COMPLIMENTI = "\nComplimenti %s, hai VINTO!! Sei riuscito a battere %s\n";
	private static final String TAMA_VITA = "\n%s ha %d di vita\n";
	private static final String MSG_COMBATTIMENTO_TAMA = "\n%s non � pi� in grado di combattere\n";
	
	private static final String PETRA_NON_VALIDA = "\nHai finito le pietre dell'elemento che avevi a disposizione";
	private static final int MAX_PIETRE = 3;
	
	private static final String MESS_PIETRE = "\nDigitare il numero dell'elemento della pietra da inserire al Tamagolem. Dovrai inserire 4 pietre. "
			+ "\nRICORDA che per l'intera partita hai a disposizione massimo 2 pietre per ogni elemento e ogni Tamagolem NON pu� avere due pietre uguali\n";
	
	private static final String MESS_PIETRE_SCELTA = "\nELENCO PIETRE DISPONIBILI\n"
			+ "0: Fuoco\n"
            + "1: Acqua\n"
            + "2: Terra\n"
            + "3: Erba\n"
            + "4: Aria\n"
            + "5: Elettricit�\n"
            + "6: Acciaio\n"
            + "\nDigita il numero corrispondente all'elemento per inserire la pietra al tuo tamagolem: ";
	
	
	/**
	 * METODO totaleScontro.
	 * Si occupa dello scontro tra i due giocatori.
	 * 
	 * @param giocatore1
	 * @param giocatore2
	 * @param eq
	 */
	public static void totaleScontro(Giocatore giocatore1, Giocatore giocatore2, Equilibrio eq) 
	{
		int i = 0; 
        int iterazioniTamaG1 = 0;
    	int iterazioniTamaG2 = 0;
    	
    	int sFuoco = MAX_PIETRE;
    	int sAcqua = MAX_PIETRE;
    	int sTerra = MAX_PIETRE;
    	int sErba = MAX_PIETRE;
    	int sAria = MAX_PIETRE;
    	int sElettricit� = MAX_PIETRE;
    	int sAcciaio = MAX_PIETRE;
    	
    	int[] pietreDisponibiliG1;
    	pietreDisponibiliG1 = new int[7];
    	pietreDisponibiliG1[0] = sFuoco;
    	pietreDisponibiliG1[1] = sAcqua;
    	pietreDisponibiliG1[2] = sTerra;
    	pietreDisponibiliG1[3] = sErba;
    	pietreDisponibiliG1[4] = sAria;
    	pietreDisponibiliG1[5] = sElettricit�;
    	pietreDisponibiliG1[6] = sAcciaio;
    	
    	
    	int[] pietreDisponibiliG2;
    	pietreDisponibiliG2 = new int[7];
      	pietreDisponibiliG2[0] = sFuoco;
    	pietreDisponibiliG2[1] = sAcqua;
    	pietreDisponibiliG2[2] = sTerra;
    	pietreDisponibiliG2[3] = sErba;
    	pietreDisponibiliG2[4] = sAria;
    	pietreDisponibiliG2[5] = sElettricit�;
    	pietreDisponibiliG2[6] = sAcciaio;
        
        System.out.println("\nSi scontrano i giocatori:");  
        System.out.printf(INFO_GIOCATORE, giocatore1.getNome(), giocatore1.getTamagolem().size());
        System.out.println("\t\tVS");
        System.out.printf(INFO_GIOCATORE, giocatore2.getNome(), giocatore2.getTamagolem().size());
       
        System.out.printf(GIOC_PIETRE, giocatore1.getNome(), giocatore2.getNome());
        pietreDisponibiliG1 = Scontro.addPietre(giocatore1.getTamagolem().get(0), eq, pietreDisponibiliG1);
        
        System.out.printf("\n" + GIOC_PIETRE, giocatore2.getNome(), giocatore1.getNome());
        pietreDisponibiliG2 = Scontro.addPietre(giocatore2.getTamagolem().get(0), eq, pietreDisponibiliG2);
        
        System.out.println("\nINIZIA LO SCONTRO!!!\n"
        		+ giocatore1.getNome() + " schiera " + giocatore1.getTamagolem().get(i).getNome() + "\n"
        				+ giocatore2.getNome() + " schiera " + giocatore2.getTamagolem().get(i).getNome());
       
        int mortig1 = 0;
    	int mortig2 = 0;
    	boolean morto1 = false;
    	boolean morto2 = false;
    	
        do 
        {
        	if (mortig1 > 0 || mortig2 > 0)
        	{
        		if(morto1) 
        		{
        			
        			System.out.printf(TAMA_PIETRE, giocatore1.getTamagolem().get(mortig1).getNome(), giocatore1.getNome());
        			pietreDisponibiliG1 = Scontro.addPietre(giocatore1.getTamagolem().get(mortig1), eq, pietreDisponibiliG1);
        		}
        		else 
        		{
        			System.out.printf(TAMA_PIETRE, giocatore2.getTamagolem().get(mortig2).getNome(), giocatore2.getNome());
        			pietreDisponibiliG2 = Scontro.addPietre(giocatore2.getTamagolem().get(mortig2), eq, pietreDisponibiliG2);
        		}
        	} 
        	
        	morto1 = false;
        	morto2 = false;
        	
        	Equilibrio eqTemp = eq;
        	
        	int temp = Scontro.turno(giocatore1, giocatore2, mortig1, mortig2, eqTemp, iterazioniTamaG1, iterazioniTamaG2);
        	if(giocatore1.getTamagolem().get(mortig1).getVita() <= 0) 
        	{
        		mortig1 = mortig1 + 1;
        		morto1 = true;
        		iterazioniTamaG2 = temp;
        		iterazioniTamaG1 = 0;
        	}
        	else 
        	{
        		mortig2 = mortig2 + 1;
        		morto2 = true;
        		iterazioniTamaG1 = temp;
        		iterazioniTamaG2 = 0;
        	}
        	
        } while(mortig1 < 4 && mortig2 < 4);
       
        if(mortig1 < mortig2)
        	System.out.printf(MSG_COMPLIMENTI, giocatore1.getNome(), giocatore2.getNome());
    
        else
        	System.out.printf(MSG_COMPLIMENTI, giocatore2.getNome(), giocatore1.getNome());
    }
	
	
	
	/**
	 * METODO addPietre.
	 * Questo metodo serve per aggiungere le pietre ai tamagolem
	 * 
	 * @parama tama1, il tamagolem a cui aggiungere le pietre
	 * @param equilibrio, l'equilibrio degli elementi a cui fare riferimento
	 * @param sceltaDisp, array
	 * 
	 * @return array di interi
	 */
	public static int[] addPietre(TamaGolem tama1, Equilibrio equilibrio, int[] sceltaDisp) 
	{   
        System.out.println(MESS_PIETRE);
        int countF = 0;
        int countAcq = 0;
        int countT = 0;
        int countE = 0;
        int countAr = 0;
        int countEl = 0;
        int countAcc = 0;
        
        for(int i = 0; i < 4; i++) 
        {
        	Elementi tempE = new Elementi();
            int scelta = InputDati.leggiIntero(MESS_PIETRE_SCELTA, 0, 6);
            
            switch(scelta) 
            {
            	case 0:
	            	if(sceltaDisp[scelta] > 0 && countF == 0) 
	            	{
	            		tempE = equilibrio.getFuoco();
	            		tama1.getPietre().add(tempE);
	            		sceltaDisp[scelta] = sceltaDisp[scelta] - 1;
	            		countF++;
	            	}
	            	else 
	            	{
	            		System.out.println(PETRA_NON_VALIDA);
	            		i = i - 1;
	            	}
	                break;
	                
	            case 1:
	            	if(sceltaDisp[scelta] > 0 && countAcq == 0) 
	            	{
	            		tempE=equilibrio.getAcqua();
	            		tama1.getPietre().add(tempE);
	            		sceltaDisp[scelta] = sceltaDisp[scelta] - 1;
	            		countAcq++;
	            	} 
	            	else 
	            	{
	            		System.out.println(PETRA_NON_VALIDA);
	            		i = i - 1;
	            	}
	                break;
	                
	            case 2:
	            	if(sceltaDisp[scelta] > 0 && countT == 0) 
	            	{
	            		tempE = equilibrio.getTerra();
	            		tama1.getPietre().add(tempE);
	            		sceltaDisp[scelta] = sceltaDisp[scelta] - 1;
	            		countT++;
	            	}
	            	else 
	            	{
	            		System.out.println(PETRA_NON_VALIDA);
	            		i = i - 1;
	            	}
	                break;
	                
	            case 3:
	            	if(sceltaDisp[scelta] > 0 && countE == 0) 
	            	{
	            		tempE = equilibrio.getErba();
	            		tama1.getPietre().add(tempE);
	            		sceltaDisp[scelta] = sceltaDisp[scelta] - 1;
	            		countE++;
	            	}
	            	else 
	            	{
	            		System.out.println(PETRA_NON_VALIDA);
	            		i = i - 1;
	            	}	             
	                break;
	                
	            case 4:
	            	if(sceltaDisp[scelta] > 0 && countAr == 0 ) 
	            	{
	            		tempE = equilibrio.getAria();
	            		tama1.getPietre().add(tempE);
	            		sceltaDisp[scelta] = sceltaDisp[scelta] - 1;
	            		countAr++;
	            	}
	            	else 
	            	{
	            		System.out.println(PETRA_NON_VALIDA);
	            		i = i - 1;
	            	}
	                break;
	                
	            case 5:
	            	if(sceltaDisp[scelta] > 0 && countEl == 0) 
	            	{
	            		tempE = equilibrio.getElettricit�();
	            		tama1.getPietre().add(tempE);
	            		sceltaDisp[scelta] = sceltaDisp[scelta] - 1;
	            		countEl++;
	            	}
	            	else 
	            	{
	            		System.out.println(PETRA_NON_VALIDA);
	            		i = i - 1;
	            	}
	                break;
	                
	            case 6:
	            	if(sceltaDisp[scelta]> 0 && countAcc == 0) 
	            	{
	            		tempE = equilibrio.getAcciaio();
	            		tama1.getPietre().add(tempE);
	            		sceltaDisp[scelta] = sceltaDisp[scelta] - 1;
	            		countAcc++;
	            	}
	            	else 
	            	{
	            		System.out.println(PETRA_NON_VALIDA);
	            		i = i - 1;
	            	}
	                
	                break;
            } // switch
        }  // for
        System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        return sceltaDisp;
    }
    
	
	/**
     * METODO turno.
     * Metodo per la gestione del singolo turno.
     * 
     * @param g1, primo giocatore
     * @param g2, secondo giocatore
     * @param mortig1, quantit� di tamagolem morti di g1
     * @param mortig2, quantit� di tamagolem morti di g2
     * @param equilibrio, equilibrio degli elementi a cui fare riferimento
     */
   public static int turno(Giocatore g1, Giocatore g2, int mortig1, int mortig2, Equilibrio equilibrio, int iG1, int iG2) 
   {
	   System.out.println("\nINIZIO TURNO");
	   String s1 = "";
	   String s2 = "";
	   Elementi e1 = new Elementi();
	   Elementi e2 = new Elementi();
	  
	   do {	
		   switch(iG1) 
		   {
			   case 0:
				   s1 = g1.getTamagolem().get(mortig1).getPietre().get(iG1).getNome();
				   break;
				   
			   case 1:
				   s1 = g1.getTamagolem().get(mortig1).getPietre().get(iG1).getNome();
				   break;
				   
			   case 2:
				   s1 = g1.getTamagolem().get(mortig1).getPietre().get(iG1).getNome();
				   break;
				   
			   case 3:
				   s1 = g1.getTamagolem().get(mortig1).getPietre().get(iG1).getNome();
				   break;
		   } // switch iG1
		  
		   switch(iG2) 
		   {
			   case 0:
				   s2 = g2.getTamagolem().get(mortig2).getPietre().get(iG2).getNome();
				   break;
				   
			   case 1:
				   s2 = g2.getTamagolem().get(mortig2).getPietre().get(iG2).getNome();
				   break;
				   
			   case 2:
				   s2 = g2.getTamagolem().get(mortig2).getPietre().get(iG2).getNome();
				   break;
				   
			   case 3:
				   s2 = g2.getTamagolem().get(mortig2).getPietre().get(iG2).getNome();
				   break;
		   } // switch iG2
		   
		   if( !s1.equals(s2) ) 
		   {
		   		e1 = equilibrio.findElement(s1);
		   		e2 = equilibrio.findElement(s2);
		   		int tempD1 = e1.getCollegamentiElementi().get(e2);
		   		int tempD2 = e2.getCollegamentiElementi().get(e1);
		   
		   		if(tempD1 > tempD2) 
		   		{
		   			int tempD = e1.getCollegamentiElementi().get(e2)-e2.getCollegamentiElementi().get(e1);
		   			int tempV = g2.getTamagolem().get(mortig2).getVita() - tempD;
		   			g2.getTamagolem().get(mortig2).setVita(tempV);
		   		}
		   		else
		   			g1.getTamagolem().get(mortig1).setVita(g1.getTamagolem().get(mortig1).getVita() - ( e2.getCollegamentiElementi().get(e1) - e1.getCollegamentiElementi().get(e2) ));
		   } // if
		    
		   System.out.printf(TAMA_VITA, g1.getTamagolem().get(mortig1).getNome(), g1.getTamagolem().get(mortig1).getVita());
		   System.out.printf(TAMA_VITA, g2.getTamagolem().get(mortig2).getNome(), g2.getTamagolem().get(mortig2).getVita());
		   
		   iG1 = iG1 + 1;
		   if(iG1 == 4)
			   iG1 = 0;
		  
		   iG2 = iG2 + 1;
		   if(iG2 == 4)
			   iG2 = 0;
		   
	   } while(g1.getTamagolem().get(mortig1).getVita() > 0 && g2.getTamagolem().get(mortig2).getVita() > 0); // do - while();
	   
	   if (g1.getTamagolem().get(mortig1).getVita() <= 0 && g2.getTamagolem().get(mortig2).getVita() > 0) 
	   {
		   System.out.printf(MSG_COMBATTIMENTO_TAMA, g1.getTamagolem().get(mortig1).getNome());
		   return iG2;
	   }
	   
	   if (g2.getTamagolem().get(mortig2).getVita() <= 0 && g1.getTamagolem().get(mortig1).getVita() > 0) 
	   {
		   System.out.printf(MSG_COMBATTIMENTO_TAMA, g2.getTamagolem().get(mortig2).getNome());
		   return iG1;
	   }
	   
	   return 0;
   }

}