package it.unibs.ing.progettoarnaldo.tamagolem;

import java.util.HashMap;
import java.util.Map;

import it.unibs.fp.mylib.InputDati;

/*
 * Classe per la gestione della partita e per le scelte di azioni
 */
public class TamaGolemMenu {

	private static final String ANOTHER_GAME = "\nBella partita, volete farne un'altra o la sconfitta � stata troopo bruciante? Se volete la rivincita premete 1 altriementi premete 0 ";
	private static final String SPIEGONE = "Giocatori benvenuti in questo magico mondo, ognuno di voi avr� a disposizione dei tamagolem a cui affidare delle pietre.\n"
		+ "Ogni pietra rappresenta un elemento, ogni elemento � forte su alcuni elementi e debole su altri, ma attenzione ... agli elementi piace cambiare.\n"
		+ "Farete scontrare un tamagolem alla volta e ogni tamagolem avr� 4 pietre a disposizione.\n"
		+ "Ogni turno il tamagolem attaccher� con le sue pietre in ordine di inserimento fino a che lui o il suo avversario sono vivi, chi avr� usato la pietra rappresentante l'elemento debole rispetto alla scelta dell'altro far� subire al proprio tamagolem dei danni.\n"
		+ "Ogni elemento reca da 1 a 4 danni, il tamagolem subir� la differenza tra i danni che fa il suo elemento debole e i danni che fa l'elemento forte dell'avversario\n"
		+ "Se un tamagolem ha scagliato l'attacco usando la pietra che rappresenta l'elemento forte non subir� danni.\n"
		+ "CHE VINCA IL MIGLIORE!";
	
	/*
	 * metodo per la gestione della partita
	 */
	public static void match () 
	{
		Map<Elementi, Integer> temporanea1 = new HashMap<Elementi, Integer>();
		Map<Elementi, Integer> temporanea2 = new HashMap<Elementi, Integer>();
		Map<Elementi, Integer> temporanea3 = new HashMap<Elementi, Integer>();
		Map<Elementi, Integer> temporanea4 = new HashMap<Elementi, Integer>();
		Map<Elementi, Integer> temporanea5 = new HashMap<Elementi, Integer>();
		Map<Elementi, Integer> temporanea6 = new HashMap<Elementi, Integer>();
		Map<Elementi, Integer> temporanea7 = new HashMap<Elementi, Integer>();
		
		Elementi fuoco = new Elementi("fuoco", temporanea1);
		Elementi acqua = new Elementi("acqua", temporanea2);
		Elementi terra = new Elementi("terra", temporanea3);
		Elementi erba = new Elementi("erba", temporanea4);
		Elementi aria = new Elementi("aria", temporanea5);
		Elementi elettricit� = new Elementi("elettricit�", temporanea6);
		Elementi acciaio = new Elementi("acciaio", temporanea7);
		Equilibrio equilibrioMondo = new Equilibrio(fuoco, acqua, terra, erba, aria , elettricit�, acciaio);
		
		equilibrioMondo.creaEquilibrio();	
		
		Giocatore uno = new Giocatore();
		Giocatore due = new Giocatore();
		
		int scelta = 0;
		do 
		{
			int spiega = InputDati.leggiIntero("Vuoi sapere le regole?\n1. SI\n2. NO\nInserire scelta: ", 1, 2);
			
			if(spiega == 1)
				System.out.println(SPIEGONE);
			
			System.out.println("\nDATI DEL PRIMO GIOCATORE");
			uno = uno.creaGiocatore();
			
			System.out.println("\nDATI DEL SECONDO GIOCATORE");
			due = due.creaGiocatore();
			
			System.out.println("\nINIZIA LA PARTITA!!");
			
			Scontro.totaleScontro(uno, due, equilibrioMondo);
			
			System.out.println(equilibrioMondo.toString());
			
			scelta = InputDati.leggiIntero(ANOTHER_GAME, 0, 1);
			
		} while (scelta != 0);
		
	}

	

	
}