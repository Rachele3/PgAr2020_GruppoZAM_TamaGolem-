package it.unibs.ing.progettoarnaldo.tamagolem;

import java.util.HashMap;
import java.util.Map;

import it.unibs.fp.mylib.EstrazioniCasuali;
/*
 * classe per la gestione dell'equilibrio
 */
public class Equilibrio {
	
	
	private Map<Elementi, Integer> temporanea1 = new HashMap<Elementi, Integer>();
	private Map<Elementi, Integer> temporanea2 = new HashMap<Elementi, Integer>();
	private Map<Elementi, Integer> temporanea3 = new HashMap<Elementi, Integer>();
	private Map<Elementi, Integer> temporanea4 = new HashMap<Elementi, Integer>();
	private Map<Elementi, Integer> temporanea5 = new HashMap<Elementi, Integer>();
	private Map<Elementi, Integer> temporanea6 = new HashMap<Elementi, Integer>();
	private Map<Elementi, Integer> temporanea7 = new HashMap<Elementi, Integer>();
	
	// I SETTE ELEMENTI RESPONSABILI DELL'EQUILIBRIO DEL MONDO
	private Elementi fuoco = new Elementi("fuoco", temporanea1);
	private Elementi acqua = new Elementi("acqua", temporanea2);
	private Elementi terra = new Elementi("terra", temporanea3);
	private Elementi erba = new Elementi("erba", temporanea4);
	private Elementi aria = new Elementi("aria", temporanea5);
	private Elementi elettricita = new Elementi("elettricit�", temporanea6);
	private Elementi acciaio = new Elementi("acciaio", temporanea7);
	
	// COSTRUTTORE DELLA CLASSE EQUILIBRIO
	public Equilibrio(Elementi _fuoco, Elementi _acqua, Elementi _terra, Elementi _erba, Elementi _aria, 
			Elementi _elettricit�, Elementi _acciaio) 
	{
		fuoco = _fuoco;
		acqua = _acqua;
		terra = _terra;
		erba = _erba;
		aria = _aria;
		elettricita = _elettricit�;
		acciaio = _acciaio;
	}
	
	
	/**
	 * METODO creaEquilibrio.
	 * Verr� generato un equilibrio pseudo - casuale con i 7 elementi disponibili,
	 * che stabilir� quale sar� l'elemento pi� forte e quale quello pi� debole.
	 * 
	 * @see Elementi #addCollegamento(Elementi, Integer)
	 * @see EstrazioniCasuali #estraiIntero(int, int)
	 */
	public void creaEquilibrio() 
	{
		for (int i = 1; i <= 3; i++) 
		{
			/**  @param genera un numero intero casuale tra 1 e 4  */
			int randomDamage = EstrazioniCasuali.estraiIntero(1, 4);
			int damage = 5;
			
			switch(i)
			{
				case 1:
					this.fuoco.addCollegamento(this.acqua, randomDamage);
					this.acqua.addCollegamento(this.fuoco, damage - randomDamage);
					this.fuoco.addCollegamento(this.terra, damage - randomDamage);
					this.terra.addCollegamento(this.fuoco, randomDamage);
					
					break;
					
				case 2:
					this.fuoco.addCollegamento(this.erba, randomDamage);
					this.erba.addCollegamento(this.fuoco, damage - randomDamage);			
					this.fuoco.addCollegamento(this.aria, damage - randomDamage);
					this.aria.addCollegamento(this.fuoco, randomDamage);
					
					break;
					
				case 3:
					this.fuoco.addCollegamento(this.elettricita, randomDamage);
					int temp1 = damage - randomDamage;  // variabile di appoggio
					this.elettricita.addCollegamento(this.fuoco, temp1);
					this.fuoco.addCollegamento(this.acciaio, damage - randomDamage);
					this.acciaio.getCollegamentiElementi().put(this.fuoco, randomDamage);
					
					break;
			} // switch
			
		} // for
		
		
		for (int i = 2; i <=3 ; i++) 
		{
			int damage = 5;
		
			switch(i)
			{
				case 2:
					this.acqua.addCollegamento(this.terra, damage - this.acqua.getCollegamentiElementi().get(this.fuoco));
					this.terra.addCollegamento(this.acqua, damage - (damage - this.acqua.getCollegamentiElementi().get(this.fuoco)));
					this.acqua.addCollegamento(this.erba, this.erba.getCollegamentiElementi().get(fuoco));
					this.erba.addCollegamento(this.acqua, damage - this.erba.getCollegamentiElementi().get(fuoco));
					this.acqua.addCollegamento(this.aria, damage - this.acqua.getCollegamentiElementi().get(erba));
					this.aria.addCollegamento(this.acqua, this.acqua.getCollegamentiElementi().get(erba));
					
					break;
					
				case 3:
					this.acqua.addCollegamento(this.elettricita, this.elettricita.getCollegamentiElementi().get(fuoco));
					this.elettricita.addCollegamento(this.acqua, damage - this.elettricita.getCollegamentiElementi().get(fuoco));
					this.acqua.addCollegamento(this.acciaio, damage - this.elettricita.getCollegamentiElementi().get(fuoco));
					this.acciaio.addCollegamento(this.acqua,  this.elettricita.getCollegamentiElementi().get(fuoco));
					
					break;
			} // switch
			
		} // for
		
		for (int i = 2; i <= 3; i++) 
		{
			int randomDamage = EstrazioniCasuali.estraiIntero(1, 4);
			int damage = 5;
			
			switch(i)
			{
				case 2:
					this.terra.addCollegamento(this.erba, randomDamage);
					this.erba.addCollegamento(this.terra, damage - randomDamage);
					this.terra.addCollegamento(this.aria, damage - randomDamage);
					this.aria.addCollegamento(this.terra, randomDamage);
					
					break;
					
				case 3:
					this.terra.addCollegamento(this.elettricita, randomDamage);
					this.elettricita.addCollegamento(this.terra, damage - randomDamage);
					this.terra.addCollegamento(this.acciaio, damage - randomDamage);
					this.acciaio.addCollegamento(this.terra, randomDamage);
					
					break;
			} // switch
			
		} // for
		
		for (int i = 2; i <= 3; i++) 
		{
			int damage = 5;
			
			switch(i)
			{
				case 2:
					this.erba.addCollegamento(this.aria, damage - this.erba.getCollegamentiElementi().get(this.terra));
					this.aria.addCollegamento(this.erba, damage - this.aria.getCollegamentiElementi().get(terra));
					
					break;
					
				case 3:
					this.erba.addCollegamento(this.elettricita, this.elettricita.getCollegamentiElementi().get(terra));
					this.elettricita.addCollegamento(this.erba, damage - this.elettricita.getCollegamentiElementi().get(terra));
					this.erba.addCollegamento(this.acciaio, damage - this.elettricita.getCollegamentiElementi().get(terra));
					this.acciaio.addCollegamento(this.erba, this.elettricita.getCollegamentiElementi().get(terra));
					
					break;
			} // switch
			
		} // for
		
		int damage = 5;
		int randomDamage = EstrazioniCasuali.estraiIntero(1, 4);
		
		this.aria.addCollegamento(this.elettricita, randomDamage);
		this.elettricita.addCollegamento(this.aria, damage - randomDamage);
		this.aria.addCollegamento(this.acciaio, damage - randomDamage);
		this.acciaio.addCollegamento(this.aria, randomDamage);
		this.elettricita.addCollegamento(this.acciaio, randomDamage);
		this.acciaio.addCollegamento(this.elettricita, damage-randomDamage);
			
	}
	
	
	/**
	 * METODO findElement.
	 * Si occupa di trovare l'elemento corrispondente alla stringa passata come riferimento e di restituirlo.
	 * 
	 * @param name
	 * @return l'elemento che corrisponde al parametro attuale name
	 */
	public Elementi findElement(String name) 
	{
		Elementi el = new Elementi();
		
		switch(name) 
		{
			case "fuoco":
				el = this.fuoco;			
				break;
				
			case "erba":
				el = this.erba;
				break;
				
			case "acqua":
				el = this.acqua;
				break;
				
			case "terra":
				el = this.terra;
				break;
				
			case "acciaio":
				el = this.acciaio;
				break;
				
			case "elettricit�":
				el = this.elettricita;
				break;
				
			case "aria":
				el = this.aria;
				break;
		} // switch
		
		return el;
	}
	
	
	// GETTERS DEGLI ELEMENTI
	public Elementi getAcciaio() {
		return acciaio;
	}
	public Elementi getFuoco() {
		return fuoco;
	}
	public Elementi getAcqua() {
		return acqua;
	}
	public Elementi getTerra() {
		return terra;
	}
	public Elementi getErba() {
		return erba;
	}
	public Elementi getAria() {
		return aria;
	}
	public Elementi getElettricit�() {
		return elettricita;
	}
	/*
	 * Metodo per creare una stringa per visualizzare l'equilibrio
	 * @return una stringa rappresentante l'equilibrio
	 */
	@Override
	public String toString() {
		return "L'equilibrio di questo mondo �: \n"
				+ fuoco.getNome()+" fa "+ fuoco.getCollegamentiElementi().get(acqua)+ " danni ad acqua, "+ fuoco.getCollegamentiElementi().get(terra)+" danni a terra, "+ fuoco.getCollegamentiElementi().get(erba)+" danni a erba, "+ fuoco.getCollegamentiElementi().get(aria)+" danni ad aria, "+ fuoco.getCollegamentiElementi().get(elettricita)+" danni ad elettricit�, "+fuoco.getCollegamentiElementi().get(acciaio)+" danni ad acciaio.\n"
				+ acqua.getNome()+" fa "+ acqua.getCollegamentiElementi().get(fuoco)+" danni a fuoco, "+ acqua.getCollegamentiElementi().get(terra)+" danni a terra, "+ acqua.getCollegamentiElementi().get(erba)+" danni a erba, "+acqua.getCollegamentiElementi().get(aria)+ " danni ad aria, "+ acqua.getCollegamentiElementi().get(elettricita)+" danni ad elettricit�, "+ acqua.getCollegamentiElementi().get(acciaio)+" danni ad acciaio.\n"
				+ terra.getNome()+" fa "+terra.getCollegamentiElementi().get(fuoco)+ " danni a fuoco, "+terra.getCollegamentiElementi().get(acqua)+" danni ad acqua, "+ terra.getCollegamentiElementi().get(erba)+" danni ad erba, "+terra.getCollegamentiElementi().get(aria)+" danni ad aria, "+terra.getCollegamentiElementi().get(elettricita)+" danni ad elettricit�, "+terra.getCollegamentiElementi().get(acciaio)+" danni ad acciaio.\n"
				+ erba.getNome()+" fa "+erba.getCollegamentiElementi().get(fuoco)+ " danni a fuoco, "+erba.getCollegamentiElementi().get(acqua)+" danni ad acqua, "+ erba.getCollegamentiElementi().get(terra)+" danni ad terra, "+erba.getCollegamentiElementi().get(aria)+" danni ad aria, "+erba.getCollegamentiElementi().get(elettricita)+" danni ad elettricit�, "+erba.getCollegamentiElementi().get(acciaio)+" danni ad acciaio.\n"
				+ aria.getNome()+" fa "+aria.getCollegamentiElementi().get(fuoco)+ " danni a fuoco, "+aria.getCollegamentiElementi().get(acqua)+" danni ad acqua, "+ aria.getCollegamentiElementi().get(terra)+" danni ad terra, "+aria.getCollegamentiElementi().get(erba)+" danni ad erba, "+aria.getCollegamentiElementi().get(elettricita)+" danni ad elettricit�, "+aria.getCollegamentiElementi().get(acciaio)+" danni ad acciaio.\n"
				+ elettricita.getNome()+" fa "+elettricita.getCollegamentiElementi().get(fuoco)+ " danni a fuoco, "+elettricita.getCollegamentiElementi().get(acqua)+" danni ad acqua, "+ elettricita.getCollegamentiElementi().get(terra)+" danni ad terra, "+elettricita.getCollegamentiElementi().get(erba)+" danni ad erba, "+elettricita.getCollegamentiElementi().get(aria)+" danni ad aria, "+elettricita.getCollegamentiElementi().get(acciaio)+" danni ad acciaio.\n"
				+ acciaio.getNome()+" fa "+acciaio.getCollegamentiElementi().get(fuoco)+ " danni a fuoco, "+acciaio.getCollegamentiElementi().get(acqua)+" danni ad acqua, "+ acciaio.getCollegamentiElementi().get(terra)+" danni ad terra, "+acciaio.getCollegamentiElementi().get(erba)+" danni ad erba, "+acciaio.getCollegamentiElementi().get(aria)+" danni ad aria, "+acciaio.getCollegamentiElementi().get(elettricita)+" danni ad elettricit�.\n";
	}

}
