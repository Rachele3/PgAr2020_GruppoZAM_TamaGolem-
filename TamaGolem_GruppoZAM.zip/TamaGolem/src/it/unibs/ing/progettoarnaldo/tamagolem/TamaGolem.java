package it.unibs.ing.progettoarnaldo.tamagolem;

import java.util.Vector;
/*
 * classe per la gestione del tamagolem
 */

public class TamaGolem {

	private static final int N = 7;

	/** @param P sono le pietre degli elementi che ogni TamaGolem pu� ingurgitare */
	private static final int P = (int)(Math.ceil(((N + 1) / 3.0) + 1));    // P = 4
	
	private static final int V = 10;
	
	
	private String nome;
	private Vector<Elementi> pietre = null;
	private int vita = V;
	
	
	public TamaGolem(String nome, Vector<Elementi> _pietre,int _vita) {
		this.nome = nome;
		this.pietre = _pietre;
		this.vita = _vita;
	}

	public TamaGolem () {
		
	}

	
	
	@Override
	public String toString() {
		return "TamaGolem [nome = " + nome + ", pietre = " + pietre + ", vita = " + vita + "]";
	}

	
	// GETTERS E SETTERS
	public String getNome() {
		return nome.toUpperCase();
	}

	public Vector<Elementi> getPietre() {
		return pietre;
	}

	public int getVita() {
		return vita;
	}
	
	public void setVita(int vita) {
		this.vita = vita;
	}

	public static int getN() {
		return N;
	}

	public static int getP() {
		return P;
	}

	public static int getV() {
		return V;
	}
	
	
	
	
}
