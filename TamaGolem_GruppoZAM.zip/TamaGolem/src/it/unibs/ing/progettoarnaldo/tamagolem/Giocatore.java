package it.unibs.ing.progettoarnaldo.tamagolem;

import java.util.Vector;

import it.unibs.fp.mylib.InputDati;

/*
 * classe per la gestione del giocatore
 */
public class Giocatore {
	
	/**  @param G � la quantit� fissata di tamagolen a disposizione di ciascun giocatore */
	private static final int G = (int)(Math.ceil((TamaGolem.getN() - 1)*(TamaGolem.getN() - 2) / (2.0 * TamaGolem.getP()))); // G = 4
	
	private String nome;
	private Vector <TamaGolem> tamagolem = new Vector<TamaGolem>(G);
	
	// COSTRUTTORI DELLA CLASSE GIOCATORE
	public Giocatore(String nome, Vector<TamaGolem> tamagolem) 
	{
		this.nome = nome;
		this.tamagolem = tamagolem;
	}

	public Giocatore () {
		
	}
	
	
	/**
	 * METODO creaGiocatore.
	 * Questo metodo crea un giocatore con i suoi TamaGolem
	 * 
	 * @return oggetto di tipo Giocatore
	 */
	public Giocatore creaGiocatore() 
	{
		Vector<TamaGolem> t = new Vector<TamaGolem>();
		TamaGolem t1 = new TamaGolem();
		String nome_t1; // nome del TamaGolem
		
		String nome = InputDati.leggiStringaNonVuota("\nInserire il nome del giocatore: ");
		
		System.out.println("Crea i tuoi " + G + " tamagolem");
		
		for (int i = 0; i < Giocatore.getG(); i++) 
		{
			nome_t1 = InputDati.leggiStringaNonVuota("Inserire nome Tamagolem numero " + (i + 1) + ": ");
			Vector<Elementi> elementi = new Vector<Elementi>();
			int vita = 10;
			t1 = new TamaGolem (nome_t1, elementi, vita);
			t.add(t1); // viene aggiunto il TamaGolem al Vector di TamaGolem del giocatore
		}
		
		Giocatore g1 = new Giocatore (nome, t);
		
		return g1;
	}
	
	
	@Override
	public String toString() {
		return "Giocatore [nome = " + nome + ", tamagolem = " + tamagolem + "]";
	}


	// GETTERS per renderli visibili fuori dalla classe in cui sono dichiarati
	public String getNome() {
		return nome.toUpperCase();
	}

	public Vector<TamaGolem> getTamagolem() {
		return tamagolem;
	}
	
	public static int getG() {
		return G;
	}
	
}